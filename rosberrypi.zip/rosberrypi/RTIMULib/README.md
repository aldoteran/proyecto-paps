# RTIMULib - a versatile C++ and Python 9-dof, 10-dof and 11-dof IMU library

## Please note that this library is obsolete - it was replaced by RTIMULib2


