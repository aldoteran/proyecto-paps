### MPU 6050 + hmc5883 node for ROS using the /dev/i2c-x device

#Code is unmaintained
